package com.ving.partner.common;

import lombok.Data;

import java.io.Serializable;

/**
 * 通用分页请求参数
 *
 * @Author ving
 * @Date 2024/5/19 17:30
 */
@Data
public class PageRequest implements Serializable {


    private static final long serialVersionUID = 7528851733380135568L;
    /**
     * 页面大小
     */
    protected int pageSize=  10;

    /**
     * 当前是第几页
     */
    protected int pageNum = 1;
}
